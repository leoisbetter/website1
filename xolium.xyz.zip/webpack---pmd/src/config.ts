export const apiBase = "https://api.premid.app/v3/";
export const releaseType: "BETA" | "ALPHA" | "RELEASE" | "DEV" = "RELEASE";
export const requiredAppVersion = 214;
